# Rupee Rush — Endless Runner Prototype

A mobile-friendly, browser-playable endless runner prototype.

## Run
Open `index.html` in a modern browser. On desktop, use Left/Right arrows and Space/Up to jump. On mobile, use the on-screen buttons or swipe left/right and swipe up.

## Included
- Three-lane runner with increasing speed
- Jump action, barriers and crates
- Fictional rupee-style pickups (Rs. 1,000 / Rs. 5,000 labels)
- Demo wallet and mission progress
- Demo withdrawal UI with JazzCash/Easypaisa selection and Rs. 20k/30k/50k/100k choices
- Local best distance and demo points saved in browser storage

## Critical limitations
- This is a front-end prototype only: no backend, accounts, identity verification, anti-cheat service, real wallet ledger, payment APIs, or actual payouts.
- All collected amounts are fictional demo points and have no cash value. Withdrawal preview never sends money.
- Do not represent demo balances as cash that can actually be withdrawn.
- Before real payouts: confirm a permitted payout arrangement with the provider, fund the reward reserve, define eligibility and dispute rules, implement server-side ledger and fraud controls, publish clear terms/privacy policy, and get legal/compliance advice relevant to the operating model.
- Not affiliated with Subway Surfers, JazzCash, or Easypaisa.
